from django.shortcuts import render
from .models import *

# Create your views here.
def index(request):
    posts = Blog.objects.order_by('-id')[:4]
    context = {
        'posts':posts,
    }
    return render(request, 'index.html', context)

def gallery(request):
    return render(request, 'gallery.html')

def blog(request):
    posts = Blog.objects.order_by('-id')
    context = {
        'posts':posts,
    }
    return render(request, 'blog.html', context)

def blogpage(request, slug):
    myslug = Blog.objects.get(slug = slug)
    # blogpost = Blog.objects.filter(slug = myslug)
    
    context = {
        'blogpost': myslug
    }
    return render(request, 'blog-details.html', context )