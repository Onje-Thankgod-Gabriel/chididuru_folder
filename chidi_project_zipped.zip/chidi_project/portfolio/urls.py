from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static



urlpatterns = [
    path('', views.index, name='index'),
    path('gallery/', views.gallery, name='gallery'),
    path('blog/', views.blog, name='blog'),
    path('blog/<slug:slug>/', views.blogpage, name='blogpage'),
]

urlpatterns += static(settings.MEDIA_URL, document_root= settings.MEDIA_ROOT) 